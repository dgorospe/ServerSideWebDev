﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class careersales : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ApplicationButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("Application.aspx");
    }
    protected void careersMainButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("Careers.aspx");
    }
}