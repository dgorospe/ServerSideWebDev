﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class MyProfile : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
   
    protected void Page_Load(object sender, EventArgs e)
    {
   
        
        con.Open();
        try
        {
            if (Session["username"] == null)
            {
                Response.Write("This area is only for members.");
                Response.Write("<a href='Login.aspx'>Login</a>");
            }
            else
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Users WHERE username = '" + Session["username"].ToString() + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                TxtFName.Text = dt.Rows[0]["firstname"].ToString();
                TxtLName.Text = dt.Rows[0]["lastname"].ToString();
                TxtEmail.Text = dt.Rows[0]["email"].ToString();
                TxtHome.Text = dt.Rows[0]["home"].ToString();
                Label3.Style.Add(HtmlTextWriterStyle.FontStyle, "Italic");
                Label3.Text = dt.Rows[0]["firstname"].ToString() + "!";

            }
        }
        catch
        {
            Label1.Visible = true;
            Label1.Text = "Invalid username and password";
        }
       
        con.Close();
        
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
       
        
        SqlCommand cmd = new SqlCommand("UPDATE Users SET firstname = '" + TxtFName.Text + "', lastname = '" + TxtLName.Text + "', email = '" + TxtEmail.Text + "', home = '" + TxtHome.Text + "'WHERE username = '" + Session["username"] + "'", con);
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
        Label1.Visible = true;
        Label1.Text = "Update successful!";
        
        
       
    }
    protected void btnlogout_Click(object sender, EventArgs e)
    {
        Session["username"] = null ;
        Response.Redirect("~/Default.aspx");
    }
}