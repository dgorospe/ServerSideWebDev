﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Net;
using System.Net.Mail;

public partial class ContactUs : System.Web.UI.Page
{
   

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (CommentsTextBox.Text.Length > 20)
            args.IsValid = false;
        else
            args.IsValid = true;
    }
    protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        FromLabel.Text = EmailTextBox.Text;
        SummaryRatingLabel.Text = RatingTextBox.Text;
        SummaryCommentsLabel.Text = CommentsTextBox.Text;


        SendMail(EmailTextBox.Text, CommentsTextBox.Text);
    }
    private void SendMail(string From, string body)
    {
        try
        {
            System.Net.Mail.SmtpClient mailClient = new System.Net.Mail.SmtpClient("smtp.gmail.com", 587);
            MailMessage message = new MailMessage(From, "interplanetarytravel2016@gmail.com");
            mailClient.EnableSsl = true;
            mailClient.Send(message);
            message.Dispose();
        }
        catch
        {
            lblmessage.Visible = true;
            lblmessage.CssClass="alert alert-danger";
            lblmessage.Text = "Your message was not send, please try again later!";
        }




    }
    protected void ReturnButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}