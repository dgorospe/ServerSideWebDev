﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
    }
    protected void CreateButton_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("INSERT into Users (firstname, lastname, home, email, username, pwd, userrole) VALUES ('"+ FNTextBox.Text + "', '"+ LNTextBox.Text +"', '"+ HomeTextBox.Text +"', '" + EmailTextBox.Text + "','" + UserNameTextBox.Text + "','" +  PWTextBox.Text + "','" + AdminDropDownList.Text + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();
        GridView1.DataBind();
        IDTextbox.Text = "";
        FNTextBox.Text = "";
        LNTextBox.Text = "";
        HomeTextBox.Text = "";
        EmailTextBox.Text = "";
        UserNameTextBox.Text = "";
        PWTextBox.Text = "";
        AdminDropDownList.Text = "";

    }
    protected void UpdateButton_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("UPDATE Users SET firstname = '" + FNTextBox.Text + "', lastname = '" + LNTextBox.Text + "', home = '" + HomeTextBox.Text + "', email = '" + EmailTextBox.Text + "', username = '" + UserNameTextBox.Text + "', pwd = '" + PWTextBox.Text + "', userrole = '"+ AdminDropDownList.Text +"' WHERE userid = '" + IDTextbox.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        GridView1.DataBind();
        IDTextbox.Text = "";
        FNTextBox.Text = "";
        LNTextBox.Text = "";
        HomeTextBox.Text = "";
        EmailTextBox.Text = "";
        UserNameTextBox.Text = "";
        PWTextBox.Text = "";
        AdminDropDownList.Text = "";
    }
    protected void DeleteButton_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE userid = '" + IDTextbox.Text + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        GridView1.DataBind();
        IDTextbox.Text = "";
        FNTextBox.Text = "";
        LNTextBox.Text = "";
        HomeTextBox.Text = "";
        EmailTextBox.Text = "";
        UserNameTextBox.Text = "";
        PWTextBox.Text = "";
        AdminDropDownList.Text = "";
    }
    protected void SearchButton_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("SELECT userid FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchIDLabel.Text = cmd.ExecuteScalar().ToString();
        SqlCommand cmd2 = new SqlCommand("SELECT username FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchUsernameLabel.Text = cmd2.ExecuteScalar().ToString();
        SqlCommand cmd3 = new SqlCommand("SELECT pwd FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchPWLabel.Text = cmd3.ExecuteScalar().ToString();
        SqlCommand cmd4 = new SqlCommand("SELECT email FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchEmailLabel.Text = cmd4.ExecuteScalar().ToString();
        SqlCommand cmd5 = new SqlCommand("SELECT userrole FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchUserroleLabel.Text = cmd5.ExecuteScalar().ToString();
        SqlCommand cmd6 = new SqlCommand("SELECT firstname FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchFNLabel.Text = cmd6.ExecuteScalar().ToString();
        SqlCommand cmd7 = new SqlCommand("SELECT lastname FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchLNLabel.Text = cmd7.ExecuteScalar().ToString();
        SqlCommand cmd8 = new SqlCommand("SELECT home FROM [dbo].[Users] WHERE userid ='" + IDTextbox.Text + "' OR username = '" + UserNameTextBox.Text + "' OR email ='" + EmailTextBox.Text + "' OR firstname = '" + FNTextBox.Text + "' OR lastname ='" + LNTextBox.Text + "' OR home ='" + HomeTextBox.Text + "'", con);
        searchHomeLabel.Text = cmd8.ExecuteScalar().ToString();

        cmd.ExecuteNonQuery();
        con.Close();
 
        lblres.Visible = true;
        ResultIDLabel.Visible = true;
        ResultFNLabel.Visible = true;
        ResultLNLabel.Visible = true;
        ResultHomeLabel.Visible = true;
        ResultEmailLabel.Visible = true;
        ResultUsernameLabel.Visible = true;
        ResultPWLabel.Visible = true;
        ResultUseroleLabel.Visible = true;

        searchIDLabel.Visible = true;
        searchFNLabel.Visible = true;
        searchLNLabel.Visible = true;
        searchHomeLabel.Visible = true;
        searchEmailLabel.Visible = true;
        searchUsernameLabel.Visible = true;
        searchPWLabel.Visible = true;
        searchUserroleLabel.Visible = true;
    }
    protected void ClearButton_Click(object sender, EventArgs e)
    {
         IDTextbox.Text = "";
         FNTextBox.Text = "";
         LNTextBox.Text = "";
         HomeTextBox.Text = "";
         EmailTextBox.Text = ""; 
         UserNameTextBox.Text = "";
         PWTextBox.Text = "";
         AdminDropDownList.Text = "";
         
         lblres.Visible = false;
         ResultIDLabel.Visible = false;
         ResultFNLabel.Visible = false;
         ResultLNLabel.Visible = false;
         ResultHomeLabel.Visible = false;
         ResultEmailLabel.Visible = false;
         ResultUsernameLabel.Visible = false;
         ResultPWLabel.Visible = false;
         ResultUseroleLabel.Visible = false;
         
         searchIDLabel.Visible = false;
         searchFNLabel.Visible = false;
         searchLNLabel.Visible = false;
         searchHomeLabel.Visible = false;
         searchEmailLabel.Visible = false;
         searchUsernameLabel.Visible = false;
         searchPWLabel.Visible = false;
         searchUserroleLabel.Visible = false;
         
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        IDTextbox.Text = GridView1.SelectedRow.Cells[1].Text;
        FNTextBox.Text = GridView1.SelectedRow.Cells[2].Text;
        LNTextBox.Text = GridView1.SelectedRow.Cells[3].Text;
        HomeTextBox.Text = GridView1.SelectedRow.Cells[4].Text;
        EmailTextBox.Text = GridView1.SelectedRow.Cells[5].Text;
        UserNameTextBox.Text = GridView1.SelectedRow.Cells[6].Text;
        PWTextBox.Text = GridView1.SelectedRow.Cells[7].Text;
        AdminDropDownList.Text = GridView1.SelectedRow.Cells[8].Text;
    }


}