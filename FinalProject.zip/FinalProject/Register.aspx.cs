﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


public partial class Register : System.Web.UI.Page
{

  

    protected void Page_Load(object sender, EventArgs e)
    {
  
    }

    protected void BtnRegister_Click(object sender, EventArgs e)
    {
        try
        {                 
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            con.Open();
            
            SqlCommand com = new SqlCommand("INSERT into Users (firstname, lastname, home, email, username, pwd, userrole) VALUES ('" + TxtFName.Text + "','" + TxtLName.Text + "','" + TxtHome.Text + "','" + TxtEmail.Text + "','" + TxtUser.Text + "','" + TxtPw.Text + "','"+ 'U'+"')", con);
            /* 
             * //string insertquery = " INSERT into Users (firstname, lastname, home, email, username, pwd, userrole) VALUES(@fn, @ln, @home, @email, @un, @pwd, @userrole) ";
             * SqlCommand com = new SqlCommand(insertquery, con);
             com.Parameters.AddWithValue("@fn", TxtFName.Text);
             com.Parameters.AddWithValue("@ln", TxtLName.Text);
             com.Parameters.AddWithValue("@home", TxtHome.Text);
             com.Parameters.AddWithValue("@email", TxtEmail.Text);
             com.Parameters.AddWithValue("@un", TxtUser.Text);
             com.Parameters.AddWithValue("@pwd", TxtPw.Text);
             com.Parameters.AddWithValue("@userrole", 'U');
             */
            com.ExecuteNonQuery();
           
            MessageLabel.Visible = true;
            MessageLabel.Text = "You have been registered! You will be automatically redirected to our login page.";
            
            Response.Redirect("~/Login.aspx");

            con.Close();


        }
        catch
        {
            Label3.Visible = true;
            Label3.CssClass = "alert alert-danger";
            Label3.Text = "Username already exists";
        }

           
    }
}