﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
 
    }

    protected void CalendarDeparture_SelectionChanged(object sender, EventArgs e)
    {
        TextBoxDeparture_PopupControlExtender.Commit(CalendarDeparture.SelectedDate.ToShortDateString());
       
    }
    protected void CalendarArrival_SelectionChanged(object sender, EventArgs e)
    {
        TextBoxArrival_PopupControlExtender.Commit(CalendarArrival.SelectedDate.ToShortDateString());
    }
    protected void DDLDestination_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ButtonBook_Click(object sender, EventArgs e)
    {

    }
    protected void Reset_Click(object sender, EventArgs e)
    {
        DDLDestination.SelectedIndex = 0;
        DDLFlightOp.SelectedIndex = 0; 
        TextBoxDeparture.Text = "";
        TextBoxArrival.Text = "";
        TextBoxRooms.Text="";
        TextPassengers.Text = "";

    }
    protected void Button_Command(object sender, CommandEventArgs e)
    {

        if (e.CommandName == "Reset")
        {DDLDestination.SelectedIndex = 0;
        DDLFlightOp.SelectedIndex = 0; 
        TextBoxDeparture.Text = "";
        TextBoxArrival.Text = "";
        TextBoxRooms.Text="";
        TextPassengers.Text = "";

        }
        if (e.CommandName == "ButtonBook" & Page.IsValid)
        {
          MessageLabel.Visible=true;
            MessageLabel.Text = "You're item has been added!";
        }
    }
}