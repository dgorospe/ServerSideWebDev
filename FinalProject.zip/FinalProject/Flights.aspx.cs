﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Flights : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
            con.Open();

            SqlCommand com = new SqlCommand("INSERT into Flights (type, price, destination) VALUES ('" + txttype.Text + "','" + txtprice.Text + "','" + txtdestination.Text +  "')", con);
           
            com.ExecuteNonQuery();

            MessageLabel.Visible = true;
            MessageLabel.Text = "Flight has been added";

            con.Close();


        }
        catch
        {
            MessageLabel.Visible = true;
            MessageLabel.CssClass = "alert alert-danger";
            MessageLabel.Text = "Username already exists";
        }

    }
}