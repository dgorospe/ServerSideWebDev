﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;


public partial class Account : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            if (Request.Cookies["username"] != null && Request.Cookies["pwd"] != null)
            {
                txtun.Text = Request.Cookies["username"].Value;
                Password.Attributes["value"] = Request.Cookies["pwd"].Value;
            }
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("select * from Users where username='" + txtun.Text + "'", con);
        //SqlCommand cmd = new SqlCommand("SELECT pwd FROM Users WHERE username = '" + txtun.Text + "'");
        cmd.Connection = con;

        try
        {
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            string passw = "";
            string role = "";
            //string user = "";


            while (reader.Read())
            {
                passw = reader["pwd"].ToString().Trim();
                role = reader["userrole"].ToString().Trim();
                //user = reader["username"].ToString().Trim();

                if (role == "A" && Password.Text == passw)
                {
                    Response.Redirect("Admin.aspx");
                }
                if (role == "U" && Password.Text == passw)
                {
                    Session["username"] = txtun.Text;
                    Response.Redirect("MyProfile.aspx");
                }
                if (Password.Text != passw )
                {
                    lblresult.Visible = true;
                    lblresult.Text = "Password do not match!";
                }

            }
            lblresult.Visible = true;
            lblresult.Text = "User does not exist!";
        }
        catch (Exception ex)
        {
            lblresult.Visible = true;
            lblresult.Text = ex.ToString();
        }

        con.Close();
    }



}
