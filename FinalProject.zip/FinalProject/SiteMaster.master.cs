﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SiteMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButtonSignUp_Click(object sender, EventArgs e)
    {
        //Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "s", "window.alert('Your email has been added');", true);
        
       // if (FooterEmail.IsValid)
    
    
    }

}
